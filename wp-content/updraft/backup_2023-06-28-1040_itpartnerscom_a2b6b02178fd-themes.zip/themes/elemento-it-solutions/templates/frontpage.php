<?php 

/* Template Name: Home Page Template */

get_header(); ?>

<div id="content">
	<?php the_content(); ?>
</div>

<?php get_footer(); ?>