<?php
/**
 * The template for offline page in PWA.
 *
 * @package Hestia
 */

pwa_get_header( 'pwa' );

do_action( 'hestia_do_offline' );

pwa_get_footer( 'pwa' );
